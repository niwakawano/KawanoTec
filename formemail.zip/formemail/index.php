<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Formulario com SwiftMailker</title>
</head>

<body>
<center>
	<h1>Formulário de Email</h1>
	<form method="post" action="enviaremail.php">
		<table>
			<tr>
				<td>Nome</td>
				<td><input type="text" name="nome"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input type="text" name="email"></td>
			</tr>
			<tr>
				<td>Mensagem</td>
				<td><textarea name="mensagem" cols="25" rows="10"></textarea></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" value="Enviar"></td>
				
			</tr>
		</table>
	</form>
</center>
</body>
</html>